import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function fixAdmin() {
    try {
        // Find existing admin user
        const existingAdmin = await prisma.user.findFirst({
            where: { role: 'admin' }
        });

        if (existingAdmin) {
            console.log('Found existing admin:', existingAdmin.name);

            // Update the admin user with proper email
            const updated = await prisma.user.update({
                where: { id: existingAdmin.id },
                data: {
                    email: 'admin@organico.com',
                    phone: existingAdmin.phone || '1111111111',
                }
            });

            console.log('✅ Admin user updated successfully!');
            console.log('Email:', updated.email);
            console.log('Phone:', updated.phone);
            console.log('\nYou can now login with:');
            console.log('Email: admin@organico.com');
            console.log('Password: password123');
        } else {
            console.log('No admin user found. Creating new admin...');

            // If no admin exists, create one
            const bcrypt = await import('bcrypt');
            const hashedPassword = await bcrypt.hash('password123', 10);

            const newAdmin = await prisma.user.create({
                data: {
                    name: 'Admin User',
                    email: 'admin@organico.com',
                    phone: '1111111111',
                    password: hashedPassword,
                    role: 'admin',
                    isVerified: true,
                }
            });

            console.log('✅ New admin user created!');
            console.log('Email:', newAdmin.email);
            console.log('Phone:', newAdmin.phone);
        }

        await prisma.$disconnect();
    } catch (error) {
        console.error('Error:', error);
        await prisma.$disconnect();
    }
}

fixAdmin();
