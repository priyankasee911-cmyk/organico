# Environment Variables Configuration

## Database
```
DATABASE_URL="file:./prisma/dev.db"
```

## Demo Mode
Set to `true` to display OTP codes on screen (perfect for hackathon demos)
```
DEMO_MODE="true"
```

## Email Configuration (Production)
Only needed if `DEMO_MODE=false`. Configure your email service for sending OTP codes:

### For Gmail:
1. Enable 2-factor authentication
2. Generate an app-specific password
3. Add to .env:
```
EMAIL_SERVICE="gmail"
EMAIL_USER="your-email@gmail.com"
EMAIL_PASSWORD="your-app-specific-password"
```

### For other services:
Supported services: gmail, outlook, yahoo, etc.
```
EMAIL_SERVICE="your-service"
EMAIL_USER="your-email"
EMAIL_PASSWORD="your-password"
```

## Node Environment
```
NODE_ENV="development"
```

## Setup Instructions

1. Copy this configuration to your `.env` file
2. For hackathon/demo: Keep `DEMO_MODE="true"`
3. For production: Set `DEMO_MODE="false"` and configure email settings
4. Run `npx prisma migrate dev` to apply database changes
5. Run `npm run dev` to start the server

## Security Notes
- Never commit `.env` file to version control
- Use strong passwords for production
- Rotate email credentials regularly
- Enable 2FA on email accounts
