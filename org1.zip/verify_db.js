const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    const userCount = await prisma.user.count();
    const productCount = await prisma.product.count();

    console.log('\n=== Database Status ===');
    console.log(`Total Users: ${userCount}`);
    console.log(`Total Products: ${productCount}`);

    console.log('\n=== Users by Role ===');
    const users = await prisma.user.findMany({
        select: {
            name: true,
            email: true,
            phone: true,
            role: true,
            isVerified: true
        }
    });

    users.forEach(user => {
        console.log(`- ${user.role.toUpperCase()}: ${user.name} (${user.email || user.phone})`);
    });

    console.log('\n✅ Database seeded successfully!\n');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
