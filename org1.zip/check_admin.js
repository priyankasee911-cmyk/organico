import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkAdmin() {
    try {
        const admin = await prisma.user.findFirst({
            where: { role: 'admin' }
        });

        if (admin) {
            console.log('✅ Admin user found!');
            console.log('Email:', admin.email);
            console.log('Phone:', admin.phone);
            console.log('Name:', admin.name);
            console.log('Has password:', admin.password ? 'Yes' : 'No');
        } else {
            console.log('❌ No admin user found in database');
            console.log('You need to run: npx prisma db seed');
        }

        await prisma.$disconnect();
    } catch (error) {
        console.error('Error:', error);
        await prisma.$disconnect();
    }
}

checkAdmin();
