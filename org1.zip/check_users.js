const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

async function checkUsers() {
    console.log('\n=== Checking All Users ===\n');

    const users = await prisma.user.findMany({
        select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            role: true,
            password: true,
            isVerified: true
        }
    });

    for (const user of users) {
        console.log(`\n--- ${user.role.toUpperCase()}: ${user.name} ---`);
        console.log(`Email: ${user.email || 'N/A'}`);
        console.log(`Phone: ${user.phone}`);
        console.log(`ID: ${user.id}`);
        console.log(`Verified: ${user.isVerified}`);
        console.log(`Has Password: ${user.password ? 'YES' : 'NO'}`);

        if (user.password) {
            // Check if password is hashed (bcrypt hashes start with $2b$)
            const isHashed = user.password.startsWith('$2b$') || user.password.startsWith('$2a$');
            console.log(`Password Hashed: ${isHashed ? 'YES' : 'NO'}`);

            if (isHashed) {
                // Test password123
                const testMatch = await bcrypt.compare('password123', user.password);
                console.log(`Test 'password123': ${testMatch ? 'MATCH ✓' : 'NO MATCH ✗'}`);
            } else {
                console.log(`Password (plain): ${user.password}`);
            }
        }
    }

    console.log('\n=== Summary ===');
    console.log(`Total Users: ${users.length}`);
    const usersWithPassword = users.filter(u => u.password).length;
    const usersWithHashedPassword = users.filter(u => u.password && (u.password.startsWith('$2b$') || u.password.startsWith('$2a$'))).length;
    console.log(`Users with password: ${usersWithPassword}`);
    console.log(`Users with hashed password: ${usersWithHashedPassword}`);
    console.log(`Users needing password fix: ${usersWithPassword - usersWithHashedPassword}`);
}

checkUsers()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
