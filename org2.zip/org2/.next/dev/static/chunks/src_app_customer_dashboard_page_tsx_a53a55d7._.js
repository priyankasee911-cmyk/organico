(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_3a3b2933._.css",
  "static/chunks/src_components_6ba9fa6b._.js"
],
    source: "dynamic"
});
