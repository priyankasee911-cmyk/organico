(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_05dd0cdd._.js",
  "static/chunks/src_e8ab7d1b._.css"
],
    source: "dynamic"
});
