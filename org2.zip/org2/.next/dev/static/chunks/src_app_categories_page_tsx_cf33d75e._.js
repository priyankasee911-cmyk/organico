(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_0dbe1889._.js",
  "static/chunks/src_5ba1a988._.css"
],
    source: "dynamic"
});
