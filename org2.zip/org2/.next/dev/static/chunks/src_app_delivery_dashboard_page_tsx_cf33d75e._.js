(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_delivery_dashboard_page_module_972f8484.css",
  "static/chunks/src_app_delivery_dashboard_bae8d9b4._.js"
],
    source: "dynamic"
});
