(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_farmer_dashboard_page_module_43ef3fff.css",
  "static/chunks/src_app_farmer_dashboard_5bd3bf75._.js"
],
    source: "dynamic"
});
