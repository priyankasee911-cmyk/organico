(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_6b224ab6._.js",
  "static/chunks/src_app_forgot-password_page_module_792bc235.css"
],
    source: "dynamic"
});
