(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_647d8045._.js",
  "static/chunks/src_app_signup_page_module_0899dfb5.css"
],
    source: "dynamic"
});
