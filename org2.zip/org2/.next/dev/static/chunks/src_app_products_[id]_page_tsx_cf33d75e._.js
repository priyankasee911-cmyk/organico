(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_fd39ba41._.js",
  "static/chunks/src_7df4af21._.css"
],
    source: "dynamic"
});
