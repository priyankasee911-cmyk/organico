(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e39c3f38._.js",
  "static/chunks/src_988593bb._.css"
],
    source: "dynamic"
});
