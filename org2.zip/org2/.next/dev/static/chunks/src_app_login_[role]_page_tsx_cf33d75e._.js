(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_8564f025._.js",
  "static/chunks/src_app_login_[role]_page_module_91ab782a.css"
],
    source: "dynamic"
});
