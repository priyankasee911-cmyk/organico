(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_214746b5._.js",
  "static/chunks/src_ffba03a0._.css"
],
    source: "dynamic"
});
