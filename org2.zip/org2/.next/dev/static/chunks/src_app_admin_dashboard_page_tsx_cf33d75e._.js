(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_admin_dashboard_page_module_cd680ac0.css",
  "static/chunks/src_app_admin_dashboard_dc1f17b8._.js"
],
    source: "dynamic"
});
