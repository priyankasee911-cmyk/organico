var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/route.js")
R.c("server/chunks/node_modules_next_3f6d4e66._.js")
R.c("server/chunks/[root-of-the-server]__e20e1312._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_route_actions_595e9dd9.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/admin/users/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/admin/users/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
