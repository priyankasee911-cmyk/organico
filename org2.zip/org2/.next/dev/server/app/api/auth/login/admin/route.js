var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/admin/route.js")
R.c("server/chunks/node_modules_next_e29971fa._.js")
R.c("server/chunks/[root-of-the-server]__10f49c5b._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_admin_route_actions_f86ae781.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/login/admin/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/login/admin/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
