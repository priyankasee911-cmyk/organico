var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/route.js")
R.c("server/chunks/node_modules_next_06c09d5d._.js")
R.c("server/chunks/[root-of-the-server]__82b8b505._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_route_actions_60052b14.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/products/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/products/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
