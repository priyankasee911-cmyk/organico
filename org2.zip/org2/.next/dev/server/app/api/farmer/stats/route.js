var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/farmer/stats/route.js")
R.c("server/chunks/node_modules_next_90cedb94._.js")
R.c("server/chunks/[root-of-the-server]__6719039f._.js")
R.c("server/chunks/_next-internal_server_app_api_farmer_stats_route_actions_4a463171.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/farmer/stats/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/farmer/stats/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
