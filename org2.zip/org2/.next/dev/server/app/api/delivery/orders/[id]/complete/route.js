var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/delivery/orders/[id]/complete/route.js")
R.c("server/chunks/node_modules_next_a88a7866._.js")
R.c("server/chunks/[root-of-the-server]__a9b878e3._.js")
R.c("server/chunks/ce889_server_app_api_delivery_orders_[id]_complete_route_actions_ac803993.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/delivery/orders/[id]/complete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/delivery/orders/[id]/complete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
