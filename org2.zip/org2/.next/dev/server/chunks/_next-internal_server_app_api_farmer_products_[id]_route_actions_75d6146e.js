module.exports = [
"[project]/.next-internal/server/app/api/farmer/products/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_farmer_products_%5Bid%5D_route_actions_75d6146e.js.map