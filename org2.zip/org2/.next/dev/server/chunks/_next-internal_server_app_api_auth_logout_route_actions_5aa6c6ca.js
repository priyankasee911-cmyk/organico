module.exports = [
"[project]/.next-internal/server/app/api/auth/logout/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_auth_logout_route_actions_5aa6c6ca.js.map