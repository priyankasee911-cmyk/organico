module.exports = [
"[project]/.next-internal/server/app/api/delivery/orders/[id]/complete/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_api_delivery_orders_%5Bid%5D_complete_route_actions_ac803993.js.map