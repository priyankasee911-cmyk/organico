module.exports = [
"[project]/.next-internal/server/app/api/admin/config/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_admin_config_route_actions_4f206dcd.js.map