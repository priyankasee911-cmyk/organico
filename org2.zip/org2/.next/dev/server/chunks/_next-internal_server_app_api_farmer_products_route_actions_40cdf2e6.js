module.exports = [
"[project]/.next-internal/server/app/api/farmer/products/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_farmer_products_route_actions_40cdf2e6.js.map