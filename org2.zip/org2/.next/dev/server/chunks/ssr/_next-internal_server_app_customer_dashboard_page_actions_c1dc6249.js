module.exports = [
"[project]/.next-internal/server/app/customer/dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_customer_dashboard_page_actions_c1dc6249.js.map