module.exports = [
"[project]/.next-internal/server/app/delivery/dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_delivery_dashboard_page_actions_f07dda1a.js.map