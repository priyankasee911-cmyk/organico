module.exports = [
"[project]/.next-internal/server/app/categories/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_categories_page_actions_3c6edf35.js.map