module.exports = [
"[project]/.next-internal/server/app/admin/dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_dashboard_page_actions_b058c280.js.map